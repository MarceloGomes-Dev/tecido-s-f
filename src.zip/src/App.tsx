// App.tsx
import React, { useState } from 'react';
import { useERPState } from './useERPState';
import LoginScreen from './components/LoginScreen';
import DashboardView from './components/DashboardView';
import ClientsView from './components/ClientsView';
import OrdersView from './components/OrdersView';
import KanbanBoard from './components/KanbanBoard';
import InventoryView from './components/InventoryView';
import EmployeesView from './components/EmployeesView';
import ChatInternalView from './components/ChatInternalView';
import FinanceView from './components/FinanceView';
import AdminSettingsView from './components/AdminSettingsView';

import {
  Menu,
  X,
  Sun,
  Moon,
  Bell,
  LogOut,
  LayoutDashboard,
  Users,
  FileText,
  Trello,
  Package,
  UserCheck,
  MessageSquare,
  DollarSign,
  Settings,
  ChevronRight
} from 'lucide-react';

export default function App() {
  const state = useERPState();

  const {
    activeUser,
    theme,
    login,
    logout,
    toggleTheme,
    users,
    clients,
    products,
    categories,
    rawMaterials,
    suppliers,
    osList,
    finances,
    chatInternal,
    logs,
    notifications,
    registerUser,
    updateUserStatus,
    addClient,
    updateClient,
    addProduct,
    updateProductStock,
    addRawMaterial,
    updateRawMaterialStock,
    addCategory,
    createOS,
    advanceOSStage,
    updateOSChecklistItem,
    addOSChatMessage,
    sendInternalMessage,
    markInternalMessagesRead,
    addFinancialRecord,
    updateOSPaymentInfo,
    updateOSInvoiceInfo,
    markAllNotificationsAsRead,
    getStageLabel,
    getRoleLabel,
    monthlyGoal,
    updateMonthlyGoal,
    selectedGoalMonth,
    monthlyGoals,
    setSelectedGoalMonth,
    clearFaturamento
  } = state;

  const isDark = theme === 'escuro';

  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [showNotifications, setShowNotifications] = useState(false);

  if (!activeUser) {
    return (
      <LoginScreen
        login={login}
        theme={theme}
      />
    );
  }

  const tabs = [
    {
      id: 'dashboard',
      label: 'Painel Geral',
      icon: LayoutDashboard,
      roles: ['admin', 'atendimento']
    },
    {
      id: 'kanban',
      label: 'Fluxo de Produção',
      icon: Trello,
      roles: [
        'admin',
        'atendimento',
        'designer',
        'impressao',
        'producao',
        'costura',
        'finalizacao'
      ]
    },
    {
      id: 'orders',
      label: 'Ordens de Serviço',
      icon: FileText,
      roles: [
        'admin',
        'atendimento',
        'designer',
        'impressao',
        'producao',
        'costura',
        'finalizacao'
      ]
    },
    {
      id: 'clients',
      label: 'Clientes',
      icon: Users,
      roles: ['admin', 'atendimento']
    },
    {
      id: 'inventory',
      label: 'Estoque',
      icon: Package,
      roles: ['admin', 'atendimento', 'producao']
    },
    {
      id: 'finance',
      label: 'Financeiro e Faturamento',
      icon: DollarSign,
      roles: ['admin', 'atendimento']
    },
    {
      id: 'employees',
      label: 'Colaboradores',
      icon: UserCheck,
      roles: ['admin']
    },
    {
      id: 'chat',
      label: 'Mensagens Internas',
      icon: MessageSquare,
      roles: [
        'admin',
        'atendimento',
        'designer',
        'impressao',
        'producao',
        'costura',
        'finalizacao'
      ]
    },
    {
      id: 'settings',
      label: 'Configurações',
      icon: Settings,
      roles: ['admin']
    }
  ];

  const allowedTabs = tabs.filter(tab =>
    tab.roles.includes(activeUser.role)
  );

  const isTabAllowed = allowedTabs.some(
    tab => tab.id === activeTab
  );

  const currentTab = isTabAllowed
    ? activeTab
    : (allowedTabs[0]?.id || 'kanban');

  const unreadNotifCount = notifications.filter(
    n => !n.isRead
  ).length;

  return (
    <div
      className={`h-screen w-screen overflow-hidden font-sans flex transition-colors duration-300 ${
        isDark ? 'dark' : ''
      } ${
        isDark
          ? 'bg-[#0A0A0C] text-[#E2E8F0]'
          : 'bg-slate-50 text-black'
      }`}
    >

      <aside
        className={`w-64 hidden lg:flex flex-col justify-between border-r shrink-0 ${
          isDark
            ? 'bg-[#111114] border-white/5'
            : 'bg-white border-slate-100'
        }`}
      >

        <div className="flex flex-col flex-1">

          <div className="p-5 border-b flex items-center gap-3 border-slate-800/10 dark:border-white/5">

            <img
              src="https://github.com/MarceloGomes-Dev/LosGomes/blob/main/logo%20ts.png?raw=true"
              alt="Logo Tecido Sublimado Fortaleza"
              className="h-10 w-auto rounded object-contain"
              referrerPolicy="no-referrer"
            />

            <div>
              <h1
                className={`font-display font-bold text-xs leading-none uppercase tracking-widest ${
                  isDark
                    ? 'text-cyan-400'
                    : 'text-indigo-500'
                }`}
              >
                SubliGestão
              </h1>

              <p className="text-4xs font-mono text-slate-500 mt-1 uppercase tracking-widest leading-none">
                Fortaleza ERP
              </p>
            </div>

          </div>